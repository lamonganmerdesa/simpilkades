<?php
    $koneksi = mysqli_connect('localhost','u5963470_simpilkades','b1smillah','u5963470_simpilkades');
	date_default_timezone_set("Asia/Jakarta");
?>