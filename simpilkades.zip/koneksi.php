<?php
    $koneksi = mysqli_connect('localhost','root','','simpilkades');
	date_default_timezone_set("Asia/Jakarta");
?>